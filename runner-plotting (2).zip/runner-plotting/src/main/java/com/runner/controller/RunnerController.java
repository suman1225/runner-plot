package com.runner.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.runner.service.RunnerService;

@Controller
@RequestMapping("/runner-plotting")
public class RunnerController {

	@Autowired
	RunnerService runnerService;

	@PostMapping("/plot")
	public ResponseEntity<Map<String, Object>> runnerPlotting(@RequestBody Map<String, Object> request) {

		Map<String, Object> response = runnerService.runnerPlottingResponse(request);
		if (response != null) {
			return ResponseEntity.ok(response);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(runnerService.getFailureResponse());
		}

	}

}
