package com.runner.service;

import java.util.Map;

public interface RunnerService {
	Map<String, Object> runnerPlottingResponse(Map<String, Object> request);

	Map<String, Object> getFailureResponse();
}
