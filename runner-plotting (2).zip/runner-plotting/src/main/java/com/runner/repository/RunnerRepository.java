package com.runner.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.runner.entity.RunnerEntity;

@Repository
public interface RunnerRepository extends JpaRepository<RunnerEntity, Integer> {

	Optional<RunnerEntity> findByTaskIdAndUsername(Integer taskId, String username);

}
