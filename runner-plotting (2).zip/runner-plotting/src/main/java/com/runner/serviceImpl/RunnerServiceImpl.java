package com.runner.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.runner.entity.RunnerEntity;
import com.runner.entity.TaskEntity;
import com.runner.repository.RunnerRepository;
import com.runner.repository.TaskRepository;
import com.runner.service.RunnerService;

@Service
public class RunnerServiceImpl implements RunnerService {
	@Autowired
	RunnerRepository runnerRepository;

	@Autowired
	TaskRepository taskRepository;

	@Override
	public Map<String, Object> runnerPlottingResponse(Map<String, Object> request) {

		Map<String, Object> response = null;
		for (Map.Entry<String, Object> entry : request.entrySet()) {

			if (entry.getKey().equals("type")) {
				if (entry.getValue().equals("runner")) {
					List<TaskEntity> tasks = taskRepository.findByStatusIn(Arrays.asList("ACCEPT", "ALLOC"));
					List<Map<String, Object>> vertices = new ArrayList<>();
					List<Map<String, Object>> lines = new ArrayList<>();

					for (TaskEntity task : tasks) {
						if (task.getCurrentRunner() != null) {
							Optional<RunnerEntity> runnerOpt = runnerRepository.findByTaskIdAndUsername(task.getId(),
									task.getCurrentRunner());
							if (runnerOpt.isPresent()) {
								RunnerEntity runner = runnerOpt.get();
								double distance = calculateDistance(task.getLatitude(), task.getLongitude(),
										runner.getLatitude(), runner.getLongitude());
								String color = getLineColor(distance);

								vertices.add(createVertex("TASK", task.getLatitude(), task.getLongitude(),
										task.getCustId() + " | " + task.getStatus()));
								vertices.add(createVertex("RUNNER", runner.getLatitude(), runner.getLongitude(),
										runner.getUsername() + " | " + task.getCustId()));

								lines.add(createLine(task.getLatitude(), task.getLongitude(), runner.getLatitude(),
										runner.getLongitude(), color));
							}
						}

						response = new LinkedHashMap<>();
						response.put("statusCode", "1");
						response.put("statusMessage", "SUCCESS");
						response.put("vertices", vertices);
						response.put("lines", lines);

					}
				}
			}
		}
		return response;

	}

	private String getLineColor(double distance) {
		if (distance < 1000)
			return "#077411";
		if (distance >= 1000 && distance < 2500)
			return "#06D001";
		if (distance >= 2500 && distance < 5000)
			return "#FF8225";
		if (distance >= 5000 && distance < 10000)
			return "#FF0000";
		return "#7A1CAC";
	}

	private Map<String, Object> createVertex(String type, double latitude, double longitude, String label) {
		Map<String, Object> vertex = new LinkedHashMap<>();
		vertex.put("type", type);
		vertex.put("location", latitude + "," + longitude);
		vertex.put("image", "");
		vertex.put("label", label);
		vertex.put("timeElapsed", "");
		return vertex;
	}

	private Map<String, Object> createLine(double startLat, double startLong, double endLat, double endLong,
			String lineColor) {
		Map<String, Object> line = new LinkedHashMap<>();
		line.put("startLat", startLat);
		line.put("startLong", startLong);
		line.put("endLat", endLat);
		line.put("endLong", endLong);
		line.put("lineColor", lineColor);
		return line;
	}

	public static final double EARTH_RADIUS = 6371;

	public static double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
		double latDistance = Math.toRadians(lat2 - lat1);
		double lonDistance = Math.toRadians(lon2 - lon1);
		double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + Math.cos(Math.toRadians(lat1))
				* Math.cos(Math.toRadians(lat2)) * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		return EARTH_RADIUS * c * 1000; // result in meters
	}

	@Override
	public Map<String, Object> getFailureResponse() {
		Map<String, Object> response = new LinkedHashMap<>();
		response.put("statusCode", "0");
		response.put("statusMessage", "FAILED ");
		response.put("vertices", new ArrayList<>());
		response.put("lines", new ArrayList<>());
		return response;
	}

}
