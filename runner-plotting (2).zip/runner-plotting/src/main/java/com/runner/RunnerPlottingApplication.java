package com.runner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunnerPlottingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunnerPlottingApplication.class, args);
	}

}
