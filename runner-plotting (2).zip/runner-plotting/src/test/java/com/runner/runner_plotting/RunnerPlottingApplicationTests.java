package com.runner.runner_plotting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunnerPlottingApplicationTests {

	@Test
	void contextLoads() {
	}

}
